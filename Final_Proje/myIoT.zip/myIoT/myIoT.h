#ifndef myIoT
#define myIoT

#include "Arduino.h"
#include "FirebaseESP8266.h"
#include <ESP8266WiFi.h>

#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <WiFiManager.h>

class myIot {
  public:
    FirebaseData firebs;

  public:
    myIot(String ID, String device);
    ~myIot();
    static void initialize_firabase(char *HOST, char *AUTH);
    static void initialize_WiFi(char *APname);
    int getIntState();
    void set_int_state_to_database(int value);
    void update_int_state_from_database();

  private:
    int int_state;
    String ID;
    String path;
    int error_counter;

  private:
    void error_iot();
};

#endif
