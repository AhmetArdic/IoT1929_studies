#include "myIoT.h"

#include "Arduino.h"
#include "FirebaseESP8266.h"
#include <ESP8266WiFi.h>

#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <WiFiManager.h>

myIot ::myIot(String ID, String device) {
  this->ID = ID;
  this->path = String("/") + String(this->ID) + String("/") + String(device);
  error_counter = 0;
  int_state = 0;
}

myIot ::~myIot() {}

void myIot ::error_iot() {
  if (this->error_counter == 5) {
    this->error_counter = 0;
    Serial.println("Reset..");
    ESP.restart();
  }
  return;
}

void myIot :: update_int_state_from_database() {
  if (Firebase.getInt(this->firebs, this->path))
  {
    //Success

    int temp = this->firebs.intData();
    if ( this->int_state != temp) {
      this->int_state = temp;
    }
  }
  else {
    //Failed

    Serial.print("Error in getInt, ");
    Serial.println(this->firebs.errorReason());
    this->error_counter += 1;
  }

  this->error_iot();
}

void myIot :: set_int_state_to_database(int value) {
  this->int_state = value;
  
  if (Firebase.setInt(this->firebs, path, value)) {
    //Serial.print("Passed Value: ");
    //Serial.print("VALUE: ");
    //Serial.println(value);
  }
  else {
    Serial.println("Error in setInt, ");
    Serial.println(this->firebs.errorReason());
    this->error_counter += 1;
  }
}


void myIot ::initialize_firabase(char *HOST, char *AUTH) {
  Firebase.begin(HOST, AUTH);
  Firebase.reconnectWiFi(true);
}

void myIot ::initialize_WiFi(char *APname) {
  WiFi.mode(WIFI_STA);
  delay(10);

  WiFiManager wm;
  bool res = wm.autoConnect(APname);
  if (!res) {
    Serial.println("WiFi not connected, ESP is restarting...");
    ESP.restart();
  } else {
    Serial.print("Wifi is connected to ");
    Serial.println(APname);
  }
  delay(20);
}

int myIot :: getIntState() {
  return this->int_state;
}
